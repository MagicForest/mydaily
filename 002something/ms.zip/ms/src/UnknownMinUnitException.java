package devin.wu.training.ddl.ms;

@SuppressWarnings("serial")
public class UnknownMinUnitException extends RuntimeException
{

}
