package devin.wu.training.ddl.ms;

@SuppressWarnings("serial")
public class UnknownUnitException extends RuntimeException
{

}
